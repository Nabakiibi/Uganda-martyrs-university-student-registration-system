﻿Public Class FrmLogin

    Private users As New Dictionary(Of String, String) From {
        {"admin", "admin"},
        {"admin2", "admin2"}
    }

    Public Shared LoggedInUser As String

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim username As String = txtuser.Text
        Dim password As String = txtpass.Text

        If users.ContainsKey(username) AndAlso users(username) = password Then
            LoggedInUser = username
            Dim frmMain As New frmmain()
            frmMain.Show()
            Me.Hide()
        Else
            MessageBox.Show("Invalid username or password", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub FrmLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub
End Class